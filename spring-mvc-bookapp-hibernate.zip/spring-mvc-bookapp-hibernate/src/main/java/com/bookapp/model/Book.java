package com.bookapp.model;




import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
//@Data   //has getter setter tostring
public class Book {

	
	private String title;
	@Id
	private int bookid;
	private String author;
	private String category;
	private Double price;
	
}
