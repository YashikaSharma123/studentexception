package com.bookapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookapp.dao.BookDAO;
import com.bookapp.dao.BookDAOImpl;
import com.bookapp.exceptions.AuthorNotFoundException;
import com.bookapp.exceptions.CategoryNotFoundException;
import com.bookapp.exceptions.IdNotFoundException;
import com.bookapp.model.Book;

@Service
public class BookServiceImpl implements BookService{

	@Autowired
	BookDAO bookDAO;

	
	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		bookDAO.addOneBook(book);
	}

	@Override
	public void updateBook(int bookid, double price) throws IdNotFoundException{
		// TODO Auto-generated method stub
		bookDAO.updateOneBook(bookid, price);
	}

	@Override
	public void deleteBook(int bookid) throws IdNotFoundException{
		// TODO Auto-generated method stub
		bookDAO.deleteOneBook(bookid);
	}

	@Override
	public Book getBookById(int bookid) throws IdNotFoundException{
		// TODO Auto-generated method stub
		return bookDAO.findBookById(bookid);
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return bookDAO.findAllBooks();
		}

	@Override
	public List<Book> getBookByAuthor(String Author) throws AuthorNotFoundException{
		// TODO Auto-generated method stub
		return bookDAO.findBookByAuthor(Author);
	}

	@Override
	public List<Book> getBookByCategory(String Category) throws CategoryNotFoundException{
		// TODO Auto-generated method stub
		return bookDAO.findBookByCategory(Category);
	}

	@Override
	public List<Book> getByCartOrTitleOrAuth(String choice) {
		// TODO Auto-generated method stub
		return bookDAO.findByCartOrTitleOrAuth(choice);
	}

}
