package com.bookapp.exceptions;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler extends RuntimeException {

	
	@ExceptionHandler(IdNotFoundException.class)
	public String handleCityException(IdNotFoundException e,Model model) {
		model.addAttribute("message",e.getMessage());
		return "home";
	}
	@ExceptionHandler(Exception.class)
	public String handleOtherException(Exception e,Model model) {
		model.addAttribute("message",e.getMessage());
		return "redirect:/";
	}
	@ExceptionHandler(CategoryNotFoundException.class)
	public String handleCategoryException(CategoryNotFoundException e,Model model) {
		model.addAttribute("message",e.getMessage());
		return "redirect:/";
	}
		@ExceptionHandler(AuthorNotFoundException.class)
		public String handleAuthorException(AuthorNotFoundException e,Model model) {
			model.addAttribute("message",e.getMessage());
			return "redirect:/";
			
		
	}
}
