package com.bookapp.dao;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bookapp.model.Book;
@Repository
public class BookDAOImpl implements BookDAO{

	@Autowired
	JdbcTemplate jdbcTemplate;
	public void setDatasource(DataSource datasource) {
		jdbcTemplate.setDataSource(datasource);
	}
	@Override
	public void addOneBook(Book book) {
		// TODO Auto-generated method stub
		String sql="insert into book values(?,?,?,?,?)";
		Object[] bookList= {book.getTitle(),book.getBookid(),book.getAuthor(),book.getCategory(),book.getPrice()};
		
		jdbcTemplate.update(sql,bookList);

	}

	@Override
	public int updateOneBook(int bookid, double price) {
		String sql="update  book set price=? where bookid=?";
		
		return jdbcTemplate.update(sql,price,bookid);

	}

	@Override
	public int deleteOneBook(int bookid) {
		String sql="delete book  where bookid=?";
		return jdbcTemplate.update(sql,bookid);

	}

	@Override
	public Book findBookById(int bookid) {
		String sql="select * from  book where bookid=? ";
		BookMapper mapper=new BookMapper();
		Book book=jdbcTemplate.queryForObject(sql,mapper,bookid);
		return book;
	}

	@Override
	public List<Book> findAllBooks() {
		String sql="select * from  book  ";
		List<Book> bookList=jdbcTemplate.query(sql,new BookMapper());
		return bookList;
	}

	@Override
	public List<Book> findBookByAuthor(String author) {
		String sql="select * from  book where author=? ";
		List<Book> bookByList=jdbcTemplate.query(sql,(rs,rowNum)-> {

			Book book=new Book();						
			
			book.setAuthor(rs.getString("author"));
			book.setBookid(rs.getInt("bookid"));
			book.setCategory(rs.getString("category"));
			book.setPrice(rs.getDouble("price"));
			book.setTitle(rs.getString("title"));
			
		
		// TODO Auto-generated method stub
			return book;
	
	
			},author);

			return bookByList;
	}

	@Override
	public List<Book> findBookByCategory(String category) {
		String sql="select * from  book where category=? ";
		List<Book> bookList=jdbcTemplate.query(sql,(rs,rowNum)-> {

			Book book=new Book();						
			
			book.setAuthor(rs.getString("author"));
			book.setBookid(rs.getInt("bookid"));
			book.setCategory(rs.getString("category"));
			book.setPrice(rs.getDouble("price"));
			book.setTitle(rs.getString("title"));
			
		
		// TODO Auto-generated method stub
			return book;
	
	
			},category);

			return bookList;
	}
	@Override
	public List<Book> findByCartOrTitleOrAuth(String choice) {

		String sql="select * from book where author like ? Or category like ? Or title like ?";
		Object[] arr={choice,choice,choice};

		List<Book> bookByLists=jdbcTemplate.query(sql,new BookMapper(),arr);
			

			return bookByLists;
		
	}

}
