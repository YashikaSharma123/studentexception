package com.bookapp.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bookapp.model.Book;

public class BookMapper implements RowMapper<Book>{

	@Override
	public Book mapRow(ResultSet rs, int rowNum) throws SQLException {
		Book book=null;
			
			String title=rs.getString("title");
			int bookid=rs.getInt("bookid");
			String author=rs.getString("author");
			String category=rs.getString("category");
			Double price=rs.getDouble("price");
			
			
		
			
			book=new Book(title,bookid,author,category,price);
			return book;
		
	}
	
	

}
