
package com.bookapp.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.bookapp.model.User;
import com.bookapp.service.BookService;

@Controller //request searching for controller in dispatcher
public class UserController {
	
	@Autowired
	BookService service;
	@GetMapping ("/login")
	public String login() {
		return"login";
		}
	
	
	@PostMapping("/loginUser")
	public String loginUser(@ModelAttribute User user, Model model) {
		if(user.getUsername().equals("ram") && user.getPassword().equals("admin123")) {	
			model.addAttribute("username", user.getUsername());
			return "admin";
		}
		else if(user.getUsername().equals("ram") && user.getPassword().equals("ram")) {	
			model.addAttribute("username", user.getUsername());
			return "cart";
		}
		else {	
			model.addAttribute("errorMessage", "Invalid Credentials");
			return "login";
		}
	}
	
	
		
		
	}
	
	




