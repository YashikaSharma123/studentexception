package com.bookapp.model;




import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
//@Data   //has getter setter tostring
public class Book {

	
	private String title;
	private int bookid;
	private String author;
	private String category;
	private Double price;
	
}
