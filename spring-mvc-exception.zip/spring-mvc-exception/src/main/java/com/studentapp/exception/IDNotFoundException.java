package com.studentapp.exception;

public class IDNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IDNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IDNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
