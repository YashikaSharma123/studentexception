package com.studentapp.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler extends RuntimeException {

	
	@ExceptionHandler(IDNotFoundException.class)
	public String handleCityException(IDNotFoundException e,Model model) {
		model.addAttribute("message",e.getMessage());
		return "home";
	}
	@ExceptionHandler(Exception.class)
	public String handleOtherException(Exception e,Model model) {
		model.addAttribute("message",e.getMessage());
		return "redirect:/";
	}
}
