package com.studentapp.service;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.studentapp.exception.CityNotFoundException;
import com.studentapp.exception.IDNotFoundException;
import com.studentapp.model.Student;

public interface StudentService {

	
	Student getStudentbyId(int id) throws IDNotFoundException;
	List<Student> getStudentByCity(String city) throws CityNotFoundException;
	List<Student> getAll();
		
}
