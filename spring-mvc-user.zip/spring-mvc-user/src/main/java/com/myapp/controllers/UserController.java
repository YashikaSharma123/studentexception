package com.myapp.controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.myapp.model.User;
import com.myapp.service.UserService;
import com.myapp.service.UserServiceImpl;

@Controller //request searching for controller in dispatcher
public class UserController {
	
	
	@GetMapping("/")
	public String home(Model model) {
		
		return "home";
	
	}
	
	@GetMapping("/login")//jsp calling this by using get method

	public String loginForm(ModelMap model) {
		
		return "login";
	
	}
	
	@Autowired
	UserServiceImpl service;
	
	
	@PostMapping("/loginUser")
	//@RequestMapping(value="/loginUser",method=RequestMethod.POST)
	public String loginUser(@ModelAttribute User user,Model model) {
		
		if(!service.ValidateUser(user))
		{
				model.addAttribute("message","wrong name password");
		
				return "login";
		}
		else {
				return "show";
		}
	
	}
	@GetMapping("/showItems")//jsp calling this by using get method

	public String showItems(@RequestParam("category")String category,Model model) {
		List<String> itemsList=service.getItemsByCategory(category);
		model.addAttribute("itemList",itemsList);

		
		return "final";
	
	}
		
		
	}
	
	




