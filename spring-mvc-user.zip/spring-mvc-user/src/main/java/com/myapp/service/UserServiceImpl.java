package com.myapp.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.myapp.model.User;
@Service
public class UserServiceImpl implements UserService{

	//String[] usernames= {"yashika","ram"};
	List<String> usernames=Arrays.asList("ram","yashika");
	String passwords="admin123";
	List<String> mobiles=Arrays.asList("samsung","apple","Mac","Lenovo");
	List<String> laptops=Arrays.asList("samsung","apple","vivo","Moto");
	

	List<String> headphones=Arrays.asList("Bose","JBL","Boat");
	
	
	
	
	
	
	@Override
	public boolean ValidateUser(User user) {
		// TODO Auto-generated method stub
		int c=0;
		for(String i:usernames)
		{
			if(i.equals(user.getName())&&passwords.equals(user.getPassword()))
				c+=1;
				
				
		}
		if(c==1)
			return true;
		else
			return false;
	}
	@Override
	public List<String> getItemsByCategory(String category) {
		// TODO Auto-generated method stub
		if(category.equals("Mobile")) {
			return mobiles;
		}
		if(category.equals("Laptop")) {
			return laptops;
		}
		if(category.equals("Headphone")) {
			return headphones;
		}
		else
			return new ArrayList<>();
	}

	
	
}
