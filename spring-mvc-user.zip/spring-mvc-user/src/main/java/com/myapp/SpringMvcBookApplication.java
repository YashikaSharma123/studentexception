package com.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcBookApplication.class, args);
	}

}
